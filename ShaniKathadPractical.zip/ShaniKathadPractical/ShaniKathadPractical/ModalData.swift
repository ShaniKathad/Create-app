//
//  ModalData.swift
//  ShaniKathadPractical
//
//  Created by sunny on 25/11/20.
//  Copyright © 2020 sunny. All rights reserved.
//

import UIKit

//class Photos{
//    var isFirst:Bool
//    var img:
//}
