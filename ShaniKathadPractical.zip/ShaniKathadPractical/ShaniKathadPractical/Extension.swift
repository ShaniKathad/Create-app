//
//  Extension.swift
//  ShaniKathadPractical
//
//  Created by sunny on 25/11/20.
//  Copyright © 2020 sunny. All rights reserved.
//

import UIKit
enum BorderSide: Int
{
    case all = 0, top, bottom, left, right, customRight, customBottom
}

extension UIView
{
    func setRadius(_ radius: CGFloat? = nil)
    {
        self.layer.cornerRadius = radius ?? self.frame.height / 2
        self.layer.masksToBounds = true
    }
    
    func setBorder(_ radius:CGFloat? = nil, _ color:UIColor? = nil)
    {
        self.layer.borderWidth = radius ?? 1
        self.layer.borderColor = color?.cgColor ?? UIColor.black.cgColor
    }
    func parentView<T: UIView>(of type: T.Type) -> T?
    {
        guard let view = self.superview else
        {
            return nil
        }
        return (view as? T) ?? view.parentView(of: T.self)
    }
    //Border
    
    func border(side: BorderSide = .all, color:UIColor = UIColor.black, borderWidth:CGFloat = 1.0)
    {
        let border = CALayer()
        border.borderColor = color.cgColor
        border.borderWidth = borderWidth
        
        switch side
        {
            case .all:
                self.layer.borderWidth = borderWidth
                self.layer.borderColor = color.cgColor
            case .top:
                border.frame = CGRect(x: 0, y: 0, width:self.frame.size.width ,height: borderWidth)
            case .bottom:
                border.frame = CGRect(x: 0, y: self.frame.size.height - borderWidth, width:self.frame.size.width ,height: borderWidth)
            case .left:
                border.frame = CGRect(x: 0, y: 0, width: borderWidth, height: self.frame.size.height)
            case .right:
                border.frame = CGRect(x: self.frame.size.width - borderWidth, y: 0, width: borderWidth, height: self.frame.size.height)
            case .customRight:
                border.frame = CGRect(x: self.frame.size.width - borderWidth - 8, y: 8, width: borderWidth, height: self.frame.size.height - 16)
            case .customBottom:
                border.frame = CGRect(x: 8, y: self.frame.size.height - borderWidth , width:self.frame.size.width - 16 ,height: borderWidth)
        }
        if side.rawValue != 0
        {
            self.layer.addSublayer(border)
            self.layer.masksToBounds = true
        }
    }
    
}
extension String
{
    var isValidEmail: Bool
    {
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: self)
    }
}
