//
//  SignUpVC.swift
//  ShaniKathadPractical
//
//  Created by sunny on 25/11/20.
//  Copyright © 2020 sunny. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

class SignUpVC: UIViewController {
    
    @IBOutlet weak var photosCollection: UICollectionView!{
        didSet{
            self.photosCollection.delegate = self
            self.photosCollection.dataSource = self
        }
    }
    @IBOutlet weak var firstNameView: UIView!{
        didSet{
            DispatchQueue.main.async {
                self.firstNameView.border(side: .bottom, color: .lightGray, borderWidth: 1)
            }
        }
    }
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var lastNameView: UIView!{
        didSet{
            DispatchQueue.main.async {
                self.lastNameView.border(side: .bottom, color: .lightGray, borderWidth: 1)
            }
        }
    }
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var emailView: UIView!{
        didSet{
            DispatchQueue.main.async {
                self.emailView.border(side: .bottom, color: .lightGray, borderWidth: 1)
            }
        }
    }
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var phoneView: UIView!{
        didSet{
            DispatchQueue.main.async {
                self.phoneView.border(side: .bottom, color: .lightGray, borderWidth: 1)
            }
        }
    }
    @IBOutlet weak var txtCode: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var btnMaleImage: UIButton!
    @IBOutlet weak var btnMale: UIButton!
    @IBOutlet weak var btnFemaleImage: UIButton!
    @IBOutlet weak var btnFemale: UIButton!
    @IBOutlet weak var birthdateView: UIView!{
        didSet{
            DispatchQueue.main.async {
                self.birthdateView.border(side: .bottom, color: .lightGray, borderWidth: 1)
            }
        }
    }
    @IBOutlet weak var txtBirthdate: UITextField!
    @IBOutlet weak var confirmPassView: UIView!{
        didSet{
            DispatchQueue.main.async {
                self.confirmPassView.border(side: .bottom, color: .lightGray, borderWidth: 1)
            }
        }
    }
    @IBOutlet weak var txtConfirmPass: UITextField!
    @IBOutlet weak var createPassView: UIView!{
        didSet{
            DispatchQueue.main.async {
                self.createPassView.border(side: .bottom, color: .lightGray, borderWidth: 1)
            }
        }
    }
    @IBOutlet weak var txtCreatePass: UITextField!
    @IBOutlet weak var btnRegister: UIButton!{
        didSet{
            DispatchQueue.main.async {
                self.btnRegister.setRadius()
            }
        }
    }
    @IBOutlet weak var genderView: UIView!{
        didSet{
            DispatchQueue.main.async {
                self.genderView.border(side: .bottom, color: .lightGray, borderWidth: 1)
            }
        }
    }
    
    
    var isMale = false
    var gender:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    @IBAction func onClickMale(_ sender: UIButton) {
        if isMale{
            btnFemale.setTitleColor(UIColor(red: 245/255, green: 183/255, blue: 67/255, alpha: 1), for: .normal)
            btnFemaleImage.setImage(#imageLiteral(resourceName: "Ellipse 2"), for: .normal)
            btnMale.setTitleColor(.lightGray, for: .normal)
            btnMaleImage.setImage(#imageLiteral(resourceName: "Ellipse1"), for: .normal)
            self.gender = "Female"
            self.isMale = false
        }else{
            btnMale.setTitleColor(UIColor(red: 245/255, green: 183/255, blue: 67/255, alpha: 1), for: .normal)
            btnMaleImage.setImage(#imageLiteral(resourceName: "Ellipse 2"), for: .normal)
            btnFemale.setTitleColor(.lightGray, for: .normal)
            btnFemaleImage.setImage(#imageLiteral(resourceName: "Ellipse1"), for: .normal)
            self.gender = "Male"
            self.isMale = true
        }
    }
    
    @IBAction func onClickFemale(_ sender: UIButton) {
        if isMale{
            btnFemale.setTitleColor(UIColor(red: 245/255, green: 183/255, blue: 67/255, alpha: 1), for: .normal)
            btnFemaleImage.setImage(#imageLiteral(resourceName: "Ellipse 2"), for: .normal)
            btnMale.setTitleColor(.lightGray, for: .normal)
            btnMaleImage.setImage(#imageLiteral(resourceName: "Ellipse1"), for: .normal)
            self.gender = "Female"
            self.isMale = false
        }else{
            btnMale.setTitleColor(UIColor(red: 245/255, green: 183/255, blue: 67/255, alpha: 1), for: .normal)
            btnMaleImage.setImage(#imageLiteral(resourceName: "Ellipse 2"), for: .normal)
            btnFemale.setTitleColor(.lightGray, for: .normal)
            btnFemaleImage.setImage(#imageLiteral(resourceName: "Ellipse1"), for: .normal)
            self.gender = "Male"
            self.isMale = true
        }
    }
    @IBAction func onClickRegister(_ sender: UIButton) {
        if isValidated(){
            let param : [String:Any] = [
                "first_name":txtFirstName.text ?? "",
                "last_name":txtLastName.text ?? "",
                "email":txtEmail.text ?? "",
                "password":txtCreatePass.text ?? "",
                "code":txtCode.text ?? "",
                "phone_no":txtPhone.text ?? "",
                "birthdate":txtBirthdate.text ?? "",
                "device_type":"I",
                "gender":gender ?? ""
                
            ]
            let headers: HTTPHeaders = [
                "API-KEY": "590bf61f7a61fc559da19c7927da1c9e",
                "Content-Type": "application/x-www-form-urlencoded"
            ]
            requestGetHeader(base: "http://132.148.17.145/~hyperlinkserver/ned/api/v1/smyllo/signup/", parameters: param, headers: headers) { (dic, ary, strings) in
                print(dic)
                let status = dic?["code"] as? String
                if status == "1"{
                    print(dic?["message"] as? String ?? "")
                }else{
                    print(dic?["message"] as? String ?? "")
                }
            }
        }
    }
}
//MARK:- API Calling
extension SignUpVC{
    func requestGetHeader(base: String, parameters:[String:Any],headers: HTTPHeaders?, completion: @escaping (([String:Any]?,[[String:Any]]?, String?) -> ())){
        print("************************")
        print("URL:- \(base)")
        print("Param")
        for i in parameters{
            print("\(i.key):\(i.value)")
        }
        print("************************")
        AF.request("\(base)", method: .post, parameters: parameters,headers: headers).validate().responseJSON { (resp) in
            print(resp)
            switch resp.result{
            case .success(let data):
                print(data)
                if let json = data as? [String:Any]{
                    completion(json, nil,nil)
                }else if let jsonArr = data as? [[String:Any]]{
                    completion(nil,jsonArr,nil)
                }
            case .failure(let err):
                completion(nil,nil ,err.localizedDescription)
            }
        }
    }
}
//MARK: - Validation

extension SignUpVC{
    func isValidated() -> Bool
    {
        var ErrorMsg = ""
        if (txtFirstName.text?.isEmpty)!
        {
            ErrorMsg = "Please enter Firstname"
        }
        else  if (txtLastName.text?.isEmpty)!
        {
            ErrorMsg = "Please enter Lastname"
        }
        else if (txtEmail.text?.isEmpty)!
        {
            ErrorMsg = "Please enter email address"
        }
        else if !(txtEmail.text?.isValidEmail)!
        {
            ErrorMsg = "Please enter a valid email id"
        }
        else if (txtCode.text?.isEmpty)!
        {
            ErrorMsg = "Please enter code"
        }
        else if (txtPhone.text?.isEmpty)!
        {
            ErrorMsg = "Please enter Phone Number"
        }
        else if (txtBirthdate.text?.isEmpty)!
        {
            ErrorMsg = "Please enter Birthdate"
        }
        else if (txtCreatePass.text?.isEmpty)!
        {
            ErrorMsg = "Please enter password"
        }
        else if (txtConfirmPass.text?.isEmpty)!
        {
            ErrorMsg = "Please enter password"
        }
        else if txtCreatePass.text != txtConfirmPass.text
        {
            ErrorMsg = "create Password Or Confirm Password Not match"
        }
        if ErrorMsg != ""
        {
            let alert = UIAlertController(title: "Error", message: ErrorMsg, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .destructive, handler: nil))
            present(alert, animated: true, completion: nil)
            return false
        }
        else
        {
            return true
        }
    }
}


// MARK:- CollectionView Delegate DataSource Method

extension SignUpVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as? PhotoCell else {
            fatalError()
        }
        //        if indexPath.row == 0{
        //            cell.imgPhhots.image = UIImage(named: "add")
        //        }else if indexPath.row == images.count - 1{
        //            cell.imgPhhots.image = UIImage(named: "delete")
        //        }else{
        //            cell.imgPhhots.image = images[indexPath.row]
        //        }
        
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        let height = collectionView.frame.size.height
        return CGSize(width: height, height: height)
    }
    
}
