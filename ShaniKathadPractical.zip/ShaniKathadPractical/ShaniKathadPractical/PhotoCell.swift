//
//  PhotoCell.swift
//  ShaniKathadPractical
//
//  Created by sunny on 25/11/20.
//  Copyright © 2020 sunny. All rights reserved.
//

import UIKit

class PhotoCell: UICollectionViewCell {
    @IBOutlet weak var imgPhhots: UIImageView!{
        didSet{
            DispatchQueue.main.async {
                self.imgPhhots.setRadius()
            }
        }
    }
    
}
